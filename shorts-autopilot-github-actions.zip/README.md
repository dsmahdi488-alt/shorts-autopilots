<div align="center">
<img width="1200" height="475" alt="GHBanner" src="https://ai.google.dev/static/site-assets/images/share-ais-513315318.png" />
</div>

# Run and deploy your AI Studio app

This contains everything you need to run your app locally.

View your app in AI Studio: https://ai.studio/apps/4f9d96be-f0f5-4d34-aab0-13ede718416f

## Run Locally

**Prerequisites:**  [Android Studio](https://developer.android.com/studio)


1. Open Android Studio
2. Select **Open** and choose the directory containing this project
3. Allow Android Studio to fix any incompatibilities as it imports the project.
4. Create a file named `.env` in the project directory and set `GEMINI_API_KEY` in that file to your Gemini API key (see `.env.example` for an example)
5. Remove this line from the app's `build.gradle.kts` file: `signingConfig = signingConfigs.getByName("debugConfig")`
6. Run the app on an emulator or physical device
7. If you have already published your app in AI Studio, please [request upload key reset](https://support.google.com/googleplay/android-developer/answer/9842756#zippy=%2Crequest-an-upload-key-reset) in Google Play Console.

## Real YouTube integration

This revision removes the fake/random YouTube video IDs from the upload path and adds a real Google OAuth 2.0 client plus a resumable YouTube Data API v3 uploader. You must configure an Android OAuth client in Google Cloud and enable YouTube Data API v3. The Android package name and signing certificate must match the OAuth client configuration. The app never asks for a Google password.

The uploader expects a rendered MP4 at `filesDir/renders/short_<id>.mp4`. Video rendering is intentionally kept separate from the YouTube uploader so a failed render cannot be reported as a successful upload.
