package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.data.model.SceneItem
import com.example.data.model.SceneSerializer
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExampleRobolectricTest {

    @Test
    fun `read string from context`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val appName = context.getString(R.string.app_name)
        assertEquals("Shorts AutoPilot", appName)
    }

    @Test
    fun `test scene serialization and deserialization`() {
        val scenes = listOf(
            SceneItem(
                sceneNumber = 1,
                visualPrompt = "Cyberpunk neon street",
                durationSeconds = 7,
                narrationSegment = "Did you know that internet cables run under oceans?",
                onScreenText = "UNDERWATER INTERNET 🌊",
                drawableResId = 12345
            )
        )
        val json = SceneSerializer.serialize(scenes)
        assertNotNull(json)
        assertTrue(json.contains("Cyberpunk neon street"))

        val deserialized = SceneSerializer.deserialize(json)
        assertEquals(1, deserialized.size)
        assertEquals("Cyberpunk neon street", deserialized[0].visualPrompt)
        assertEquals("UNDERWATER INTERNET 🌊", deserialized[0].onScreenText)
        assertEquals(7, deserialized[0].durationSeconds)
    }
}
