package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "channel_settings")
data class ChannelSettings(
    @PrimaryKey
    val id: String = "primary_settings",
    val niche: String = "Technology", // Facts, Technology, History, Motivation, Science, Business, AI, Education, Entertainment
    val targetAudience: String = "Tech enthusiasts & early adopters (18-35)",
    val language: String = "English (US)",
    val countryRegion: String = "United States",
    val defaultDurationSeconds: Int = 30, // 15, 30, 45, 60
    val shortsPerDay: Int = 2,
    val uploadHour: Int = 14, // 2:00 PM
    val uploadMinute: Int = 30,
    val timeZone: String = "UTC-7 (Pacific Standard)",
    val voiceStyle: String = "Energetic & Fast-Paced",
    val voiceGender: String = "Male",
    val videoStyle: String = "Cyberpunk / Modern Neon",
    val captionStyle: String = "Bold Yellow Pop",
    val contentTone: String = "Entertaining & Analytical",
    val isAutoModeEnabled: Boolean = true,
    val dailyLimit: Int = 5,
    val aiModelProvider: String = "Gemini 3.5 Flash",
    val voiceProvider: String = "Gemini Native Audio / TTS",
    val videoRenderEngine: String = "AutoPilot Motion Studio",
    val estimatedAiCostThisMonth: Double = 3.42,
    val renderingMinutesUsed: Int = 24,
    val notifyOnGenerated: Boolean = true,
    val notifyOnScheduled: Boolean = true,
    val notifyOnPublished: Boolean = true,
    val notifyOnFailure: Boolean = true
)
