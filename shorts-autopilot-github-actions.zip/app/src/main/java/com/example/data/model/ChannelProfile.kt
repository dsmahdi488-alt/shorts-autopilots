package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "channel_profile")
data class ChannelProfile(
    @PrimaryKey
    val id: String = "primary_channel",
    val channelName: String = "Quantum Pulse",
    val handle: String = "@QuantumPulseHQ",
    val profileImageUrl: String = "",
    val subscriberCount: Long = 48520,
    val totalVideos: Int = 142,
    val isConnected: Boolean = true,
    val oauthAccountEmail: String = "creator@gmail.com",
    val oauthScopesGranted: String = "youtube.upload, youtube.readonly, youtubepartner",
    val isSandboxMode: Boolean = true,
    val lastSyncEpochMillis: Long = System.currentTimeMillis()
)
