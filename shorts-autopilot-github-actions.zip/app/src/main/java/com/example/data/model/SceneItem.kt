package com.example.data.model

data class SceneItem(
    val sceneNumber: Int,
    val visualPrompt: String,
    val durationSeconds: Int,
    val narrationSegment: String,
    val onScreenText: String,
    val drawableResId: Int = 0
)
