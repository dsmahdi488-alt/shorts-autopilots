package com.example.data.local

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import com.example.data.model.ActivityLogItem
import com.example.data.model.ChannelProfile
import com.example.data.model.ChannelSettings
import com.example.data.model.ShortItem
import com.example.data.model.ShortStatus
import com.example.data.model.TopicMemory
import kotlinx.coroutines.flow.Flow

@Dao
interface ShortsDao {
    // Shorts
    @Query("SELECT * FROM shorts ORDER BY createdAtEpochMillis DESC")
    fun getAllShorts(): Flow<List<ShortItem>>

    @Query("SELECT * FROM shorts WHERE id = :id")
    fun getShortById(id: Long): Flow<ShortItem?>

    @Query("SELECT * FROM shorts WHERE id = :id")
    suspend fun getShortByIdOnce(id: Long): ShortItem?

    @Query("SELECT * FROM shorts WHERE status = :status ORDER BY scheduledEpochMillis ASC")
    fun getShortsByStatus(status: ShortStatus): Flow<List<ShortItem>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertShort(shortItem: ShortItem): Long

    @Update
    suspend fun updateShort(shortItem: ShortItem)

    @Query("DELETE FROM shorts WHERE id = :id")
    suspend fun deleteShort(id: Long)

    // Channel Profile
    @Query("SELECT * FROM channel_profile WHERE id = 'primary_channel' LIMIT 1")
    fun getChannelProfile(): Flow<ChannelProfile?>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun saveChannelProfile(profile: ChannelProfile)

    // Channel Settings
    @Query("SELECT * FROM channel_settings WHERE id = 'primary_settings' LIMIT 1")
    fun getChannelSettings(): Flow<ChannelSettings?>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun saveChannelSettings(settings: ChannelSettings)

    // Activity Logs
    @Query("SELECT * FROM activity_logs ORDER BY timestampMillis DESC LIMIT 100")
    fun getActivityLogs(): Flow<List<ActivityLogItem>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertActivityLog(log: ActivityLogItem): Long

    @Query("DELETE FROM activity_logs")
    suspend fun clearActivityLogs()

    // Topic Memory
    @Query("SELECT * FROM topic_memory ORDER BY usedAtEpochMillis DESC LIMIT 50")
    fun getRecentTopics(): Flow<List<TopicMemory>>

    @Query("SELECT topicText FROM topic_memory ORDER BY usedAtEpochMillis DESC LIMIT 50")
    suspend fun getRecentTopicTextsOnce(): List<String>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertTopicMemory(topic: TopicMemory)
}
