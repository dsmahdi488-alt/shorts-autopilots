package com.example.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import com.example.data.model.ActivityLogItem
import com.example.data.model.ChannelProfile
import com.example.data.model.ChannelSettings
import com.example.data.model.ShortItem
import com.example.data.model.TopicMemory

@Database(
    entities = [
        ShortItem::class,
        ChannelProfile::class,
        ChannelSettings::class,
        ActivityLogItem::class,
        TopicMemory::class
    ],
    version = 1,
    exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {
    abstract fun shortsDao(): ShortsDao

    companion object {
        @Volatile
        private var INSTANCE: AppDatabase? = null

        fun getInstance(context: Context): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "shorts_autopilot.db"
                ).fallbackToDestructiveMigration().build()
                INSTANCE = instance
                instance
            }
        }
    }
}
