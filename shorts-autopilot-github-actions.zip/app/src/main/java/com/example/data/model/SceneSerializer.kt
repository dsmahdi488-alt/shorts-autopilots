package com.example.data.model

import org.json.JSONArray
import org.json.JSONObject

object SceneSerializer {
    fun serialize(scenes: List<SceneItem>): String {
        val array = JSONArray()
        scenes.forEach { scene ->
            val obj = JSONObject().apply {
                put("sceneNumber", scene.sceneNumber)
                put("visualPrompt", scene.visualPrompt)
                put("durationSeconds", scene.durationSeconds)
                put("narrationSegment", scene.narrationSegment)
                put("onScreenText", scene.onScreenText)
                put("drawableResId", scene.drawableResId)
            }
            array.put(obj)
        }
        return array.toString()
    }

    fun deserialize(json: String?): List<SceneItem> {
        if (json.isNullOrBlank()) return emptyList()
        val list = mutableListOf<SceneItem>()
        try {
            val array = JSONArray(json)
            for (i in 0 until array.length()) {
                val obj = array.getJSONObject(i)
                list.add(
                    SceneItem(
                        sceneNumber = obj.optInt("sceneNumber", i + 1),
                        visualPrompt = obj.optString("visualPrompt", ""),
                        durationSeconds = obj.optInt("durationSeconds", 5),
                        narrationSegment = obj.optString("narrationSegment", ""),
                        onScreenText = obj.optString("onScreenText", ""),
                        drawableResId = obj.optInt("drawableResId", 0)
                    )
                )
            }
        } catch (_: Exception) {
            // fallback
        }
        return list
    }
}
