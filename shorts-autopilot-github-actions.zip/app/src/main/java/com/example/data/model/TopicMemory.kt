package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "topic_memory")
data class TopicMemory(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val topicText: String,
    val niche: String,
    val usedAtEpochMillis: Long = System.currentTimeMillis()
)
