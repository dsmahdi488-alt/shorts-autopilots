package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

enum class ShortStatus {
    DRAFT,
    QUEUED,
    GENERATING,
    RENDERING,
    READY,
    UPLOADING,
    SCHEDULED,
    PUBLISHED,
    FAILED
}

enum class PrivacyStatus {
    PRIVATE,
    UNLISTED,
    PUBLIC
}

@Entity(tableName = "shorts")
data class ShortItem(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val topic: String,
    val niche: String,
    val title: String,
    val description: String,
    val hashtags: String,
    val durationSeconds: Int = 30,
    val script: String,
    val hook: String,
    val scenesJson: String = "",
    val voiceName: String = "Cinematic Male (Kore)",
    val voiceStyle: String = "Energetic & Fast-Paced",
    val backgroundMusic: String = "Cyber Lo-Fi Drive",
    val captionStyle: String = "Bold Yellow Pop",
    val status: ShortStatus = ShortStatus.DRAFT,
    val scheduledEpochMillis: Long = 0L,
    val publishedEpochMillis: Long = 0L,
    val youtubeVideoId: String = "",
    val privacyStatus: PrivacyStatus = PrivacyStatus.PRIVATE,
    val views: Int = 0,
    val likes: Int = 0,
    val comments: Int = 0,
    val averageViewDurationPercent: Int = 85,
    val retryCount: Int = 0,
    val errorMessage: String? = null,
    val createdAtEpochMillis: Long = System.currentTimeMillis()
)
