package com.example.data.repository

import com.example.R
import com.example.data.local.ShortsDao
import com.example.data.model.ActivityLogItem
import com.example.data.model.ChannelProfile
import com.example.data.model.ChannelSettings
import com.example.data.model.PrivacyStatus
import com.example.data.model.SceneItem
import com.example.data.model.SceneSerializer
import com.example.data.model.ShortItem
import com.example.data.model.ShortStatus
import com.example.data.model.TopicMemory
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.firstOrNull

class ShortsRepository(private val shortsDao: ShortsDao) {

    val allShorts: Flow<List<ShortItem>> = shortsDao.getAllShorts()
    val channelProfile: Flow<ChannelProfile?> = shortsDao.getChannelProfile()
    val channelSettings: Flow<ChannelSettings?> = shortsDao.getChannelSettings()
    val activityLogs: Flow<List<ActivityLogItem>> = shortsDao.getActivityLogs()
    val recentTopics: Flow<List<TopicMemory>> = shortsDao.getRecentTopics()

    fun getShortById(id: Long): Flow<ShortItem?> = shortsDao.getShortById(id)

    suspend fun getShortByIdOnce(id: Long): ShortItem? = shortsDao.getShortByIdOnce(id)

    suspend fun insertShort(shortItem: ShortItem): Long = shortsDao.insertShort(shortItem)

    suspend fun updateShort(shortItem: ShortItem) = shortsDao.updateShort(shortItem)

    suspend fun deleteShort(id: Long) = shortsDao.deleteShort(id)

    suspend fun saveChannelProfile(profile: ChannelProfile) = shortsDao.saveChannelProfile(profile)

    suspend fun saveChannelSettings(settings: ChannelSettings) = shortsDao.saveChannelSettings(settings)

    suspend fun logActivity(jobName: String, status: String, details: String, shortId: Long? = null, retryCount: Int = 0) {
        shortsDao.insertActivityLog(
            ActivityLogItem(
                jobName = jobName,
                status = status,
                details = details,
                shortId = shortId,
                retryCount = retryCount
            )
        )
    }

    suspend fun clearLogs() = shortsDao.clearActivityLogs()

    suspend fun recordTopicMemory(topic: String, niche: String) {
        shortsDao.insertTopicMemory(
            TopicMemory(topicText = topic, niche = niche)
        )
    }

    suspend fun getRecentTopicTexts(): List<String> = shortsDao.getRecentTopicTextsOnce()

    suspend fun seedInitialDataIfEmpty() {
        val existingShorts = allShorts.firstOrNull()
        if (!existingShorts.isNullOrEmpty()) return

        // 1. Seed Channel Profile
        shortsDao.saveChannelProfile(
            ChannelProfile(
                channelName = "Nexus Horizon",
                handle = "@NexusHorizonShorts",
                subscriberCount = 52400,
                totalVideos = 168,
                isConnected = true,
                oauthAccountEmail = "creator@nexushq.com",
                oauthScopesGranted = "youtube.upload, youtube.readonly, youtubepartner",
                isSandboxMode = false
            )
        )

        // 2. Seed Settings
        shortsDao.saveChannelSettings(
            ChannelSettings(
                niche = "Technology",
                targetAudience = "Tech enthusiasts & early adopters (18-35)",
                language = "English (US)",
                countryRegion = "United States",
                defaultDurationSeconds = 30,
                shortsPerDay = 2,
                uploadHour = 15,
                uploadMinute = 0,
                timeZone = "UTC-7 (Pacific Standard)",
                voiceStyle = "Energetic & Fast-Paced",
                voiceGender = "Male",
                videoStyle = "Cyberpunk / Modern Neon",
                captionStyle = "Bold Yellow Pop",
                contentTone = "Entertaining & Analytical",
                isAutoModeEnabled = true,
                dailyLimit = 4,
                aiModelProvider = "Gemini 3.5 Flash",
                voiceProvider = "Gemini Native Audio / TTS"
            )
        )

        // 3. Seed Topic Memories
        val pastTopics = listOf(
            "Quantum Computers Breaking Modern Encryption",
            "Why Silicon Valley Is Building Underwater Data Centers",
            "The True Speed of Neural Interface Chips",
            "How Dyson Spheres Could Power Future Civilizations"
        )
        pastTopics.forEach { topic ->
            shortsDao.insertTopicMemory(TopicMemory(topicText = topic, niche = "Technology"))
        }

        val now = System.currentTimeMillis()
        val oneHour = 3600 * 1000L
        val oneDay = 24 * 3600 * 1000L

        // Scene templates
        val scenesCyber = listOf(
            SceneItem(
                sceneNumber = 1,
                visualPrompt = "Futuristic neon high-speed fiber city grid, cinematic drone tracking shot",
                durationSeconds = 6,
                narrationSegment = "Most people think the internet travels through satellites, but that's completely false.",
                onScreenText = "THE SATELLITE MYTH 🛰️❌",
                drawableResId = R.drawable.short_scene_cyber_1789296411013
            ),
            SceneItem(
                sceneNumber = 2,
                visualPrompt = "Subsea robotic arm splicing glowing fiber optic glass in the deep Mariana Trench",
                durationSeconds = 8,
                narrationSegment = "99% of all global data flows through tiny glass fibers lying on the ocean floor at freezing depths.",
                onScreenText = "99% OF DATA IS UNDERWATER 🌊",
                drawableResId = R.drawable.short_scene_space_1789296425952
            ),
            SceneItem(
                sceneNumber = 3,
                visualPrompt = "Deep sea shark biting an armored submarine cable with electrical sparks",
                durationSeconds = 8,
                narrationSegment = "Sharks actually attack these cables because the magnetic fields mimic fish electrical signatures.",
                onScreenText = "SHARKS ATTACK FIBER CABLES 🦈⚡",
                drawableResId = R.drawable.short_scene_cyber_1789296411013
            ),
            SceneItem(
                sceneNumber = 4,
                visualPrompt = "Global map of luminous fiber networks connecting continents with high tech overlay",
                durationSeconds = 8,
                narrationSegment = "If just four major choke points were severed, entire continents would go dark in seconds. Subscribe for more crazy tech!",
                onScreenText = "WHAT IF THEY BROKE? 💥👇",
                drawableResId = R.drawable.short_scene_space_1789296425952
            )
        )

        val scenesSpace = listOf(
            SceneItem(
                sceneNumber = 1,
                visualPrompt = "Giant James Webb telescope mirror reflecting a golden supernova explosion",
                durationSeconds = 7,
                narrationSegment = "Astronomers just detected a radio signal from deep space that repeats every 22 minutes like clockwork.",
                onScreenText = "MYSTERIOUS SIGNAL DETECTED 📡",
                drawableResId = R.drawable.short_scene_space_1789296425952
            ),
            SceneItem(
                sceneNumber = 2,
                visualPrompt = "Magnetar ultra dense neutron star spinning with violent magnetic field lines",
                durationSeconds = 8,
                narrationSegment = "Normal pulsars slow down over decades, but this magnetar is defying every law of astrophysics we know.",
                onScreenText = "DEFYING ASTROPHYSICS 🌌",
                drawableResId = R.drawable.short_scene_space_1789296425952
            ),
            SceneItem(
                sceneNumber = 3,
                visualPrompt = "Futuristic deep space listening station array in Saturn's rings",
                durationSeconds = 7,
                narrationSegment = "Scientists calculate the source is 15,000 light-years away in the constellation Scutum.",
                onScreenText = "15,000 LIGHT YEARS AWAY 🔭",
                drawableResId = R.drawable.short_scene_cyber_1789296411013
            ),
            SceneItem(
                sceneNumber = 4,
                visualPrompt = "Golden cosmic monolith beacon radiating harmonic pulses",
                durationSeconds = 8,
                narrationSegment = "Could this be an artificial stellar beacon? Drop your theory in the comments and subscribe!",
                onScreenText = "ARTIFICIAL BEACON? 🛸💬",
                drawableResId = R.drawable.short_scene_history_1789296552144
            )
        )

        // 4. Seed Shorts in different pipeline stages
        // Published #1
        shortsDao.insertShort(
            ShortItem(
                topic = "The Deep Ocean Internet Cables",
                niche = "Technology",
                title = "Where 99% Of The Internet Actually Lives! 🌊 #Shorts",
                description = "You think your WiFi comes from satellites? Discover the massive subsea fiber optic cables connecting humanity. #Technology #TechFacts #Cyber #Shorts",
                hashtags = "#Shorts, #Tech, #Future, #CyberSecurity",
                durationSeconds = 30,
                hook = "Most people think the internet travels through satellites, but that's completely false.",
                script = "Most people think the internet travels through satellites, but that's completely false. 99% of all global data flows through tiny glass fibers lying on the ocean floor at freezing depths. Sharks actually attack these cables because the magnetic fields mimic fish electrical signatures. If just four major choke points were severed, entire continents would go dark in seconds. Subscribe for more crazy tech!",
                scenesJson = SceneSerializer.serialize(scenesCyber),
                status = ShortStatus.PUBLISHED,
                publishedEpochMillis = now - (2 * oneDay),
                youtubeVideoId = "dQw4w9WgXcQ",
                privacyStatus = PrivacyStatus.PUBLIC,
                views = 42800,
                likes = 3190,
                comments = 184,
                averageViewDurationPercent = 92
            )
        )

        // Published #2
        shortsDao.insertShort(
            ShortItem(
                topic = "Mysterious 22-Minute Deep Space Signal",
                niche = "Science",
                title = "NASA's Deep Space Signal That Won't Stop 📡 #Shorts",
                description = "Every 22 minutes, something is pulsing from 15,000 light-years away. Discover the cosmic magnetar mystery. #Space #Astronomy #ScienceShorts",
                hashtags = "#Shorts, #Space, #NASA, #Universe",
                durationSeconds = 30,
                hook = "Astronomers just detected a radio signal from deep space that repeats every 22 minutes like clockwork.",
                script = "Astronomers just detected a radio signal from deep space that repeats every 22 minutes like clockwork. Normal pulsars slow down over decades, but this magnetar is defying every law of astrophysics we know. Scientists calculate the source is 15,000 light-years away in the constellation Scutum. Could this be an artificial stellar beacon? Drop your theory in the comments and subscribe!",
                scenesJson = SceneSerializer.serialize(scenesSpace),
                status = ShortStatus.PUBLISHED,
                publishedEpochMillis = now - (1 * oneDay),
                youtubeVideoId = "k3b9PqZ1xVw",
                privacyStatus = PrivacyStatus.PUBLIC,
                views = 18740,
                likes = 1420,
                comments = 97,
                averageViewDurationPercent = 88
            )
        )

        // Scheduled Short for today / tomorrow
        shortsDao.insertShort(
            ShortItem(
                topic = "Neuromorphic AI Chips Explained",
                niche = "AI",
                title = "Computer Chips That Actually Grow Synapses 🧠 #Shorts",
                description = "Silicon chips are mimicking human brain synapses with 1/1000th the power consumption. Here is how neuromorphic computing changes everything. #AI #Tech #Shorts",
                hashtags = "#AI, #TechTrends, #Hardware, #Shorts",
                durationSeconds = 30,
                hook = "What if computers didn't calculate with 1s and 0s, but with actual synthetic neurons?",
                script = "What if computers didn't calculate with 1s and 0s, but with actual synthetic neurons? Neuromorphic chips mimic biological brain synapses using 1,000 times less electrical power than standard GPUs. Instead of overheating data centers, these chips fire electrical spikes only when an event occurs. This is how robots will soon process real-time vision without relying on cloud servers. Hit subscribe to stay ahead of the AI revolution!",
                scenesJson = SceneSerializer.serialize(scenesCyber),
                status = ShortStatus.SCHEDULED,
                scheduledEpochMillis = now + (4 * oneHour),
                privacyStatus = PrivacyStatus.PRIVATE,
                averageViewDurationPercent = 0
            )
        )

        // Ready for Preview
        shortsDao.insertShort(
            ShortItem(
                topic = "Pyramids Built On Ancient Lost River",
                niche = "History",
                title = "The Hidden River That Built The Pyramids 🏛️ #Shorts",
                description = "Satellite radar just uncovered a 64-kilometer buried Nile branch beneath the desert sand right next to the pyramids. #History #Egypt #Pyramids #Shorts",
                hashtags = "#History, #Egypt, #Archaeology, #Shorts",
                durationSeconds = 30,
                hook = "Scientists finally figured out how ancient Egyptians moved 2-ton stones through the desert.",
                script = "Scientists finally figured out how ancient Egyptians moved 2-ton stones through the desert. Radar satellites peering through meters of desert sand uncovered a lost 64-kilometer branch of the Nile River called the Ahramat Branch. It ran directly alongside 31 pyramids thousands of years ago. Ancient workers simply floated massive limestone blocks on cargo barges directly to the construction ramps! Follow for more mind-blowing history secrets.",
                scenesJson = SceneSerializer.serialize(scenesSpace),
                status = ShortStatus.READY,
                privacyStatus = PrivacyStatus.PRIVATE,
                averageViewDurationPercent = 0
            )
        )

        // Seed initial activity logs
        shortsDao.insertActivityLog(
            ActivityLogItem(
                jobName = "AutoPilot Daily Batch",
                status = "PUBLISHED",
                details = "Successfully uploaded 'Where 99% Of The Internet Actually Lives!' to YouTube channel via Data API v3",
                timestampMillis = now - (2 * oneDay)
            )
        )
        shortsDao.insertActivityLog(
            ActivityLogItem(
                jobName = "AutoPilot Daily Batch",
                status = "PUBLISHED",
                details = "Published 'NASA's Deep Space Signal That Won't Stop'. Metadata, captions, and audio synced.",
                timestampMillis = now - (1 * oneDay)
            )
        )
        shortsDao.insertActivityLog(
            ActivityLogItem(
                jobName = "AI Content Generation",
                status = "READY",
                details = "Generated script, 4-scene storyboard, and synthesized voiceover for 'Pyramids Built On Ancient Lost River'. Awaiting user preview approval.",
                timestampMillis = now - (30 * 60 * 1000L)
            )
        )
        shortsDao.insertActivityLog(
            ActivityLogItem(
                jobName = "YouTube Scheduled Upload",
                status = "SCHEDULED",
                details = "Scheduled 'Computer Chips That Actually Grow Synapses' for automated release at 3:00 PM.",
                timestampMillis = now - (15 * 60 * 1000L)
            )
        )
    }
}
