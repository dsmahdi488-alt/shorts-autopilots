package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "activity_logs")
data class ActivityLogItem(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val timestampMillis: Long = System.currentTimeMillis(),
    val jobName: String,
    val status: String, // QUEUED, GENERATING, RENDERING, READY, UPLOADING, SCHEDULED, PUBLISHED, FAILED
    val details: String,
    val retryCount: Int = 0,
    val shortId: Long? = null
)
