package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.BarChart
import androidx.compose.material.icons.filled.CalendarToday
import androidx.compose.material.icons.filled.Dashboard
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material.icons.filled.VideoLibrary
import androidx.compose.material3.Badge
import androidx.compose.material3.BadgedBox
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.NavigationRail
import androidx.compose.material3.NavigationRailItem
import androidx.compose.material3.NavigationRailItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.ShortsViewModel
import com.example.ui.components.ConnectChannelDialog
import com.example.ui.screens.ActivityLogsScreen
import com.example.ui.screens.AnalyticsScreen
import com.example.ui.screens.AutomationScreen
import com.example.ui.screens.CalendarScreen
import com.example.ui.screens.CreatePreviewScreen
import com.example.ui.screens.DashboardScreen
import com.example.ui.theme.AccentGreen
import com.example.ui.theme.DarkBackground
import com.example.ui.theme.DarkBorder
import com.example.ui.theme.DarkSurface
import com.example.ui.theme.ElectricIndigo
import com.example.ui.theme.MyApplicationTheme
import com.example.ui.theme.ShortsRed
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.youtube.YouTubeOAuthManager

enum class NavDestination(val label: String, val icon: ImageVector) {
    DASHBOARD("Dashboard", Icons.Default.Dashboard),
    STUDIO("Studio", Icons.Default.VideoLibrary),
    CALENDAR("Calendar", Icons.Default.CalendarToday),
    ANALYTICS("Analytics", Icons.Default.BarChart),
    AUTOMATION("Automation", Icons.Default.Tune),
    LOGS("Logs", Icons.Default.History)
}

class MainActivity : ComponentActivity() {

    private val viewModel: ShortsViewModel by viewModels()
    private lateinit var youtubeOAuth: YouTubeOAuthManager

    @OptIn(ExperimentalMaterial3Api::class)
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        youtubeOAuth = YouTubeOAuthManager(this)

        setContent {
            MyApplicationTheme {
                val shorts by viewModel.allShorts.collectAsState()
                val profile by viewModel.channelProfile.collectAsState()
                val settings by viewModel.channelSettings.collectAsState()
                val activityLogs by viewModel.activityLogs.collectAsState()
                val recentTopics by viewModel.recentTopics.collectAsState()
                val genState by viewModel.generationState.collectAsState()
                val selectedShort by viewModel.selectedShort.collectAsState()
                val userMsg by viewModel.userMessage.collectAsState()

                var currentDestination by remember { mutableStateOf(NavDestination.DASHBOARD) }
                var showConnectDialog by remember { mutableStateOf(false) }

                val snackbarHostState = remember { SnackbarHostState() }

                LaunchedEffect(userMsg) {
                    userMsg?.let {
                        snackbarHostState.showSnackbar(it)
                        viewModel.clearUserMessage()
                    }
                }

                BoxWithConstraints(modifier = Modifier.fillMaxSize()) {
                    val isExpanded = maxWidth >= 600.dp

                    Scaffold(
                        modifier = Modifier
                            .fillMaxSize()
                            .background(DarkBackground),
                        snackbarHost = { SnackbarHost(snackbarHostState) },
                        topBar = {
                            TopAppBar(
                                title = {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Box(
                                            modifier = Modifier
                                                .size(32.dp)
                                                .clip(RoundedCornerShape(8.dp))
                                                .background(ShortsRed),
                                            contentAlignment = Alignment.Center
                                        ) {
                                            Icon(
                                                imageVector = Icons.Default.VideoLibrary,
                                                contentDescription = null,
                                                tint = Color.White,
                                                modifier = Modifier.size(18.dp)
                                            )
                                        }
                                        Spacer(modifier = Modifier.width(10.dp))
                                        Column {
                                            Text(
                                                text = "Shorts AutoPilot",
                                                color = TextPrimary,
                                                fontSize = 17.sp,
                                                fontWeight = FontWeight.Bold
                                            )
                                            Text(
                                                text = if (settings?.isAutoModeEnabled == true) "AutoPilot: ACTIVE" else "AutoPilot: PAUSED",
                                                color = if (settings?.isAutoModeEnabled == true) AccentGreen else TextMuted,
                                                fontSize = 11.sp,
                                                fontWeight = FontWeight.SemiBold
                                            )
                                        }
                                    }
                                },
                                actions = {
                                    // Channel indicator button
                                    Surface(
                                        color = DarkSurface,
                                        shape = RoundedCornerShape(20.dp),
                                        border = androidx.compose.foundation.BorderStroke(1.dp, DarkBorder),
                                        modifier = Modifier.padding(end = 12.dp)
                                    ) {
                                        Row(
                                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp),
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            Box(
                                                modifier = Modifier
                                                    .size(8.dp)
                                                    .clip(CircleShape)
                                                    .background(if (profile?.isConnected == true) AccentGreen else Color.Gray)
                                            )
                                            Spacer(modifier = Modifier.width(6.dp))
                                            Text(
                                                text = profile?.channelName ?: "Connect",
                                                color = TextPrimary,
                                                fontSize = 12.sp,
                                                fontWeight = FontWeight.SemiBold
                                            )
                                        }
                                    }
                                },
                                colors = TopAppBarDefaults.topAppBarColors(
                                    containerColor = DarkSurface,
                                    titleContentColor = TextPrimary
                                )
                            )
                        },
                        bottomBar = {
                            if (!isExpanded) {
                                NavigationBar(
                                    containerColor = DarkSurface,
                                    tonalElevation = 8.dp
                                ) {
                                    NavDestination.values().forEach { dest ->
                                        val isSelected = currentDestination == dest
                                        NavigationBarItem(
                                            selected = isSelected,
                                            onClick = { currentDestination = dest },
                                            icon = {
                                                Icon(
                                                    imageVector = dest.icon,
                                                    contentDescription = dest.label,
                                                    modifier = Modifier.size(20.dp)
                                                )
                                            },
                                            label = {
                                                Text(
                                                    text = dest.label,
                                                    fontSize = 10.sp,
                                                    fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
                                                )
                                            },
                                            colors = NavigationBarItemDefaults.colors(
                                                selectedIconColor = Color.White,
                                                selectedTextColor = ShortsRed,
                                                indicatorColor = ShortsRed,
                                                unselectedIconColor = TextSecondary,
                                                unselectedTextColor = TextSecondary
                                            ),
                                            modifier = Modifier.testTag("nav_${dest.name.lowercase()}")
                                        )
                                    }
                                }
                            }
                        }
                    ) { innerPadding ->
                        Row(
                            modifier = Modifier
                                .fillMaxSize()
                                .padding(innerPadding)
                        ) {
                            if (isExpanded) {
                                NavigationRail(
                                    containerColor = DarkSurface,
                                    modifier = Modifier.fillMaxHeight()
                                ) {
                                    Spacer(modifier = Modifier.height(16.dp))
                                    NavDestination.values().forEach { dest ->
                                        val isSelected = currentDestination == dest
                                        NavigationRailItem(
                                            selected = isSelected,
                                            onClick = { currentDestination = dest },
                                            icon = {
                                                Icon(
                                                    imageVector = dest.icon,
                                                    contentDescription = dest.label,
                                                    modifier = Modifier.size(22.dp)
                                                )
                                            },
                                            label = { Text(dest.label, fontSize = 11.sp) },
                                            colors = NavigationRailItemDefaults.colors(
                                                selectedIconColor = Color.White,
                                                selectedTextColor = ShortsRed,
                                                indicatorColor = ShortsRed,
                                                unselectedIconColor = TextSecondary,
                                                unselectedTextColor = TextSecondary
                                            )
                                        )
                                    }
                                }
                            }

                            Box(modifier = Modifier.weight(1f)) {
                                when (currentDestination) {
                                    NavDestination.DASHBOARD -> DashboardScreen(
                                        channelProfile = profile,
                                        channelSettings = settings,
                                        shorts = shorts,
                                        onToggleAutoMode = { viewModel.toggleAutoMode(it) },
                                        onOpenConnectChannel = { showConnectDialog = true },
                                        onNavigateToCreate = {
                                            currentDestination = NavDestination.STUDIO
                                            viewModel.generateShort()
                                        },
                                        onSelectShortForPreview = {
                                            viewModel.selectShort(it)
                                            currentDestination = NavDestination.STUDIO
                                        }
                                    )

                                    NavDestination.STUDIO -> CreatePreviewScreen(
                                        selectedShort = selectedShort ?: shorts.firstOrNull(),
                                        generationState = genState,
                                        defaultNiche = settings?.niche ?: "Technology",
                                        channelName = profile?.channelName ?: "Shorts Studio",
                                        channelHandle = profile?.handle ?: "@ShortsStudio",
                                        onGenerate = { viewModel.generateShort(it) },
                                        onApprove = { id, immediate ->
                                            viewModel.approveShort(id, immediateUpload = immediate)
                                        },
                                        onRegenerate = { viewModel.regenerateShort(it) },
                                        onSkip = { viewModel.skipShort(it) },
                                        onUpdateMetadata = { id, title, desc, tags, priv ->
                                            viewModel.updateShortMetadata(id, title, desc, tags, priv)
                                        },
                                        onPlayVoiceover = { viewModel.speakVoiceover(it) },
                                        onStopVoiceover = { viewModel.stopVoiceover() }
                                    )

                                    NavDestination.CALENDAR -> CalendarScreen(
                                        shorts = shorts,
                                        onReschedule = { id, newTime -> viewModel.rescheduleShort(id, newTime) },
                                        onSelectShort = {
                                            viewModel.selectShort(it)
                                            currentDestination = NavDestination.STUDIO
                                        }
                                    )

                                    NavDestination.ANALYTICS -> AnalyticsScreen(
                                        shorts = shorts,
                                        topicMemories = recentTopics
                                    )

                                    NavDestination.AUTOMATION -> AutomationScreen(
                                        currentSettings = settings,
                                        onSaveSettings = { viewModel.updateSettings(it) }
                                    )

                                    NavDestination.LOGS -> ActivityLogsScreen(
                                        logs = activityLogs,
                                        onRetryJob = { viewModel.retryFailedJob(it) },
                                        onClearLogs = { viewModel.clearAllLogs() }
                                    )
                                }
                            }
                        }
                    }

                    // OAuth Connect Channel Dialog
                    if (showConnectDialog) {
                        ConnectChannelDialog(
                            onDismiss = { showConnectDialog = false },
                            onConnect = { _, _, _, isSandbox ->
                                if (isSandbox) {
                                    viewModel.connectYouTubeChannel("Sandbox Channel", "@sandbox", "sandbox", true)
                                    showConnectDialog = false
                                } else {
                                    try {
                                        youtubeOAuth.beginAuthorization()
                                        showConnectDialog = false
                                    } catch (e: Exception) {
                                        viewModel.reportExternalError(e.message ?: "OAuth setup error")
                                    }
                                }
                            }
                        )
                    }
                }
            }
        }
    }

    @Deprecated("Use Activity Result APIs in a future refactor")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: android.content.Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == YouTubeOAuthManager.REQUEST_CODE) {
            youtubeOAuth.handleActivityResult(data) { result ->
                result.onSuccess { state ->
                    viewModel.connectYouTubeChannelFromOAuth(state, youtubeOAuth.authorizationService)
                }.onFailure { error ->
                    viewModel.reportExternalError(error.message ?: "Google OAuth failed")
                }
            }
        }
    }

    override fun onDestroy() {
        if (::youtubeOAuth.isInitialized) youtubeOAuth.close()
        super.onDestroy()
    }
}