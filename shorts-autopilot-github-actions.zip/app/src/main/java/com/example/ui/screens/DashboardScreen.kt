package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.ChatBubble
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Error
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.RocketLaunch
import androidx.compose.material.icons.filled.Schedule
import androidx.compose.material.icons.filled.ThumbUp
import androidx.compose.material.icons.filled.VideoLibrary
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.ChannelProfile
import com.example.data.model.ChannelSettings
import com.example.data.model.ShortItem
import com.example.data.model.ShortStatus
import com.example.ui.components.KpiCard
import com.example.ui.theme.AccentAmber
import com.example.ui.theme.AccentCyan
import com.example.ui.theme.AccentGreen
import com.example.ui.theme.DarkBackground
import com.example.ui.theme.DarkBorder
import com.example.ui.theme.DarkSurface
import com.example.ui.theme.DarkSurfaceVariant
import com.example.ui.theme.ElectricIndigo
import com.example.ui.theme.ShortsRed
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun DashboardScreen(
    channelProfile: ChannelProfile?,
    channelSettings: ChannelSettings?,
    shorts: List<ShortItem>,
    onToggleAutoMode: (Boolean) -> Unit,
    onOpenConnectChannel: () -> Unit,
    onNavigateToCreate: () -> Unit,
    onSelectShortForPreview: (ShortItem) -> Unit,
    modifier: Modifier = Modifier
) {
    val profile = channelProfile ?: ChannelProfile()
    val settings = channelSettings ?: ChannelSettings()

    val totalGenerated = shorts.size
    val totalPublished = shorts.count { it.status == ShortStatus.PUBLISHED }
    val totalScheduled = shorts.count { it.status == ShortStatus.SCHEDULED }
    val totalReady = shorts.count { it.status == ShortStatus.READY }
    val totalFailed = shorts.count { it.status == ShortStatus.FAILED }

    val totalViews = shorts.sumOf { it.views }
    val totalLikes = shorts.sumOf { it.likes }
    val totalComments = shorts.sumOf { it.comments }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(DarkBackground)
            .padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Spacer(modifier = Modifier.height(8.dp))
            // Connected Channel Banner
            ChannelHeaderCard(
                profile = profile,
                onConnectClick = onOpenConnectChannel
            )
        }

        item {
            // AutoPilot Master Control Banner
            AutoPilotControlCard(
                settings = settings,
                onToggle = onToggleAutoMode,
                onGenerateNow = onNavigateToCreate
            )
        }

        item {
            // 2x3 Grid for Main Performance Stats
            Text(
                text = "Studio Analytics Overview",
                color = TextPrimary,
                fontSize = 17.sp,
                fontWeight = FontWeight.Bold
            )
            Spacer(modifier = Modifier.height(10.dp))
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    KpiCard(
                        title = "Shorts Generated",
                        value = "$totalGenerated",
                        subtitle = "+$totalReady ready to review",
                        icon = Icons.Default.AutoAwesome,
                        accentColor = ShortsRed,
                        modifier = Modifier.weight(1f)
                    )
                    KpiCard(
                        title = "Published Shorts",
                        value = "$totalPublished",
                        subtitle = "$totalScheduled scheduled",
                        icon = Icons.Default.VideoLibrary,
                        accentColor = AccentGreen,
                        modifier = Modifier.weight(1f)
                    )
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    KpiCard(
                        title = "Total Views",
                        value = formatNumber(totalViews.toLong()),
                        subtitle = "Avg 89% view duration",
                        icon = Icons.Default.Visibility,
                        accentColor = AccentCyan,
                        modifier = Modifier.weight(1f)
                    )
                    KpiCard(
                        title = "Total Likes",
                        value = formatNumber(totalLikes.toLong()),
                        subtitle = "$totalComments comments",
                        icon = Icons.Default.ThumbUp,
                        accentColor = AccentAmber,
                        modifier = Modifier.weight(1f)
                    )
                }
            }
        }

        item {
            // Pipeline Status Strip
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, DarkBorder, RoundedCornerShape(16.dp)),
                colors = CardDefaults.cardColors(containerColor = DarkSurface),
                shape = RoundedCornerShape(16.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "Today's Content Pipeline",
                        color = TextPrimary,
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.height(12.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        PipelineItem(label = "Ready Review", count = totalReady, color = AccentAmber)
                        PipelineItem(label = "Scheduled", count = totalScheduled, color = ElectricIndigo)
                        PipelineItem(label = "Published", count = totalPublished, color = AccentGreen)
                        PipelineItem(label = "Failed", count = totalFailed, color = ShortsRed)
                    }
                }
            }
        }

        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Recent Shorts & Drafts",
                    color = TextPrimary,
                    fontSize = 17.sp,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = "${shorts.size} Total",
                    color = TextSecondary,
                    fontSize = 13.sp
                )
            }
        }

        // List of Shorts items
        if (shorts.isEmpty()) {
            item {
                EmptyShortsCard(onCreate = onNavigateToCreate)
            }
        } else {
            items(shorts) { shortItem ->
                ShortListCard(
                    shortItem = shortItem,
                    onClick = { onSelectShortForPreview(shortItem) }
                )
            }
        }

        item {
            Spacer(modifier = Modifier.height(40.dp))
        }
    }
}

@Composable
private fun ChannelHeaderCard(
    profile: ChannelProfile,
    onConnectClick: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .border(1.dp, DarkBorder, RoundedCornerShape(18.dp)),
        colors = CardDefaults.cardColors(containerColor = DarkSurface),
        shape = RoundedCornerShape(18.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(46.dp)
                    .clip(CircleShape)
                    .background(ShortsRed),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = profile.channelName.take(1).uppercase(),
                    color = Color.White,
                    fontWeight = FontWeight.Black,
                    fontSize = 18.sp
                )
            }
            Spacer(modifier = Modifier.width(12.dp))
            Column(modifier = Modifier.weight(1f)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = profile.channelName,
                        color = TextPrimary,
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Bold,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    if (profile.isConnected) {
                        Surface(
                            color = AccentGreen.copy(alpha = 0.2f),
                            shape = RoundedCornerShape(6.dp)
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Box(
                                    modifier = Modifier
                                        .size(5.dp)
                                        .clip(CircleShape)
                                        .background(AccentGreen)
                                )
                                Spacer(modifier = Modifier.width(4.dp))
                                Text(
                                    text = "OAuth Connected",
                                    color = AccentGreen,
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.SemiBold
                                )
                            }
                        }
                    }
                }
                Spacer(modifier = Modifier.height(2.dp))
                Text(
                    text = "${profile.handle} • ${formatNumber(profile.subscriberCount)} Subscribers",
                    color = TextSecondary,
                    fontSize = 12.sp
                )
            }
            OutlinedButton(
                onClick = onConnectClick,
                shape = RoundedCornerShape(10.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, DarkBorder),
                modifier = Modifier.testTag("manage_channel_button")
            ) {
                Text(
                    text = if (profile.isConnected) "Switch" else "Connect",
                    color = TextPrimary,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.SemiBold
                )
            }
        }
    }
}

@Composable
private fun AutoPilotControlCard(
    settings: ChannelSettings,
    onToggle: (Boolean) -> Unit,
    onGenerateNow: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .border(
                1.dp,
                if (settings.isAutoModeEnabled) ShortsRed.copy(alpha = 0.5f) else DarkBorder,
                RoundedCornerShape(20.dp)
            ),
        colors = CardDefaults.cardColors(containerColor = DarkSurface),
        shape = RoundedCornerShape(20.dp)
    ) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .background(
                    Brush.horizontalGradient(
                        if (settings.isAutoModeEnabled) {
                            listOf(ShortsRed.copy(alpha = 0.14f), Color.Transparent)
                        } else {
                            listOf(Color.White.copy(alpha = 0.02f), Color.Transparent)
                        }
                    )
                )
                .padding(16.dp)
        ) {
            Column {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(40.dp)
                                .clip(CircleShape)
                                .background(
                                    if (settings.isAutoModeEnabled) ShortsRed else Color(0xFF334155)
                                ),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.RocketLaunch,
                                contentDescription = null,
                                tint = Color.White,
                                modifier = Modifier.size(20.dp)
                            )
                        }
                        Spacer(modifier = Modifier.width(12.dp))
                        Column {
                            Text(
                                text = "AUTO MODE: ${if (settings.isAutoModeEnabled) "ON" else "OFF"}",
                                color = if (settings.isAutoModeEnabled) ShortsRed else TextSecondary,
                                fontSize = 16.sp,
                                fontWeight = FontWeight.Black
                            )
                            Text(
                                text = "${settings.shortsPerDay} Shorts/day • ${settings.uploadHour}:${if (settings.uploadMinute < 10) "0" else ""}${settings.uploadMinute} daily",
                                color = TextSecondary,
                                fontSize = 12.sp
                            )
                        }
                    }

                    Switch(
                        checked = settings.isAutoModeEnabled,
                        onCheckedChange = onToggle,
                        colors = SwitchDefaults.colors(
                            checkedThumbColor = Color.White,
                            checkedTrackColor = ShortsRed
                        ),
                        modifier = Modifier.testTag("auto_mode_switch")
                    )
                }

                Spacer(modifier = Modifier.height(14.dp))

                Text(
                    text = if (settings.isAutoModeEnabled)
                        "AutoPilot is active: Monitoring schedule, generating viral topics for '${settings.niche}', rendering 9:16 videos, and scheduling to YouTube."
                    else
                        "AutoPilot is paused: Enable to allow automatic topic generation and scheduled uploads.",
                    color = TextSecondary,
                    fontSize = 12.sp,
                    lineHeight = 16.sp
                )

                Spacer(modifier = Modifier.height(14.dp))

                Button(
                    onClick = onGenerateNow,
                    colors = ButtonDefaults.buttonColors(containerColor = ShortsRed),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("quick_generate_button")
                ) {
                    Icon(
                        imageVector = Icons.Default.AutoAwesome,
                        contentDescription = null,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "Instant Generate New Short",
                        fontWeight = FontWeight.Bold,
                        fontSize = 13.sp
                    )
                }
            }
        }
    }
}

@Composable
private fun PipelineItem(label: String, count: Int, color: Color) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(
            text = "$count",
            color = color,
            fontSize = 20.sp,
            fontWeight = FontWeight.Bold
        )
        Spacer(modifier = Modifier.height(2.dp))
        Text(
            text = label,
            color = TextSecondary,
            fontSize = 11.sp
        )
    }
}

@Composable
private fun ShortListCard(
    shortItem: ShortItem,
    onClick: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(14.dp))
            .border(1.dp, DarkBorder, RoundedCornerShape(14.dp))
            .clickable { onClick() }
            .testTag("short_item_${shortItem.id}"),
        colors = CardDefaults.cardColors(containerColor = DarkSurface),
        shape = RoundedCornerShape(14.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Thumbnail indicator / 9:16 mini badge
            Box(
                modifier = Modifier
                    .size(width = 46.dp, height = 70.dp)
                    .clip(RoundedCornerShape(8.dp))
                    .background(Color(0xFF1E293B)),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Default.PlayArrow,
                    contentDescription = null,
                    tint = ShortsRed,
                    modifier = Modifier.size(24.dp)
                )
                Text(
                    text = "${shortItem.durationSeconds}s",
                    color = Color.White,
                    fontSize = 9.sp,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier
                        .align(Alignment.BottomCenter)
                        .background(Color.Black.copy(alpha = 0.7f))
                        .fillMaxWidth()
                        .padding(vertical = 1.dp),
                    textAlign = androidx.compose.ui.text.style.TextAlign.Center
                )
            }

            Spacer(modifier = Modifier.width(12.dp))

            Column(modifier = Modifier.weight(1f)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    StatusBadge(status = shortItem.status)
                    Text(
                        text = shortItem.niche,
                        color = TextMuted,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.SemiBold
                    )
                }

                Spacer(modifier = Modifier.height(4.dp))

                Text(
                    text = shortItem.title,
                    color = TextPrimary,
                    fontSize = 14.sp,
                    fontWeight = FontWeight.SemiBold,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis
                )

                Spacer(modifier = Modifier.height(4.dp))

                Text(
                    text = if (shortItem.status == ShortStatus.PUBLISHED)
                        "${formatNumber(shortItem.views.toLong())} views • ${formatNumber(shortItem.likes.toLong())} likes"
                    else if (shortItem.status == ShortStatus.SCHEDULED)
                        "Scheduled for: ${formatEpoch(shortItem.scheduledEpochMillis)}"
                    else
                        shortItem.hook,
                    color = TextSecondary,
                    fontSize = 11.sp,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }
        }
    }
}

@Composable
fun StatusBadge(status: ShortStatus) {
    val (bgColor, textColor, text) = when (status) {
        ShortStatus.PUBLISHED -> Triple(AccentGreen.copy(alpha = 0.15f), AccentGreen, "PUBLISHED")
        ShortStatus.SCHEDULED -> Triple(ElectricIndigo.copy(alpha = 0.15f), ElectricIndigo, "SCHEDULED")
        ShortStatus.READY -> Triple(AccentAmber.copy(alpha = 0.15f), AccentAmber, "READY")
        ShortStatus.GENERATING -> Triple(AccentCyan.copy(alpha = 0.15f), AccentCyan, "GENERATING")
        ShortStatus.RENDERING -> Triple(AccentCyan.copy(alpha = 0.15f), AccentCyan, "RENDERING")
        ShortStatus.UPLOADING -> Triple(ShortsRed.copy(alpha = 0.15f), ShortsRed, "UPLOADING")
        ShortStatus.QUEUED -> Triple(Color(0xFF334155), Color(0xFF94A3B8), "QUEUED")
        ShortStatus.FAILED -> Triple(ShortsRed.copy(alpha = 0.2f), ShortsRed, "FAILED")
        ShortStatus.DRAFT -> Triple(Color(0xFF334155), Color(0xFFCBD5E1), "DRAFT")
    }

    Surface(
        color = bgColor,
        shape = RoundedCornerShape(6.dp)
    ) {
        Text(
            text = text,
            color = textColor,
            fontSize = 10.sp,
            fontWeight = FontWeight.Bold,
            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
        )
    }
}

@Composable
private fun EmptyShortsCard(onCreate: () -> Unit) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .border(1.dp, DarkBorder, RoundedCornerShape(16.dp)),
        colors = CardDefaults.cardColors(containerColor = DarkSurface),
        shape = RoundedCornerShape(16.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Icon(
                imageVector = Icons.Default.AutoAwesome,
                contentDescription = null,
                tint = ShortsRed,
                modifier = Modifier.size(40.dp)
            )
            Spacer(modifier = Modifier.height(10.dp))
            Text(
                text = "No Shorts Generated Yet",
                color = TextPrimary,
                fontSize = 16.sp,
                fontWeight = FontWeight.Bold
            )
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = "Launch the AI generator to architect your first high-retention Short.",
                color = TextSecondary,
                fontSize = 12.sp,
                textAlign = androidx.compose.ui.text.style.TextAlign.Center
            )
            Spacer(modifier = Modifier.height(14.dp))
            Button(
                onClick = onCreate,
                colors = ButtonDefaults.buttonColors(containerColor = ShortsRed),
                shape = RoundedCornerShape(10.dp)
            ) {
                Text("Generate First Short", fontWeight = FontWeight.Bold)
            }
        }
    }
}

fun formatNumber(count: Long): String {
    return when {
        count >= 1_000_000 -> String.format(Locale.US, "%.1fM", count / 1_000_000.0)
        count >= 1_000 -> String.format(Locale.US, "%.1fK", count / 1_000.0)
        else -> count.toString()
    }
}

fun formatEpoch(millis: Long): String {
    if (millis <= 0) return "Not set"
    val sdf = SimpleDateFormat("MMM d, h:mm a", Locale.getDefault())
    return sdf.format(Date(millis))
}
