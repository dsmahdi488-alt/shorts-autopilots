package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CalendarToday
import androidx.compose.material.icons.filled.EditCalendar
import androidx.compose.material.icons.filled.Schedule
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.ShortItem
import com.example.data.model.ShortStatus
import com.example.ui.theme.DarkBackground
import com.example.ui.theme.DarkBorder
import com.example.ui.theme.DarkSurface
import com.example.ui.theme.DarkSurfaceVariant
import com.example.ui.theme.ElectricIndigo
import com.example.ui.theme.ShortsRed
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

@Composable
fun CalendarScreen(
    shorts: List<ShortItem>,
    onReschedule: (id: Long, newEpochMillis: Long) -> Unit,
    onSelectShort: (ShortItem) -> Unit,
    modifier: Modifier = Modifier
) {
    var selectedDayOffset by remember { mutableIntStateOf(0) }
    var reschedulingShort by remember { mutableStateOf<ShortItem?>(null) }

    val calendar = Calendar.getInstance()
    val daysList = (0..6).map { offset ->
        val c = Calendar.getInstance()
        c.add(Calendar.DAY_OF_YEAR, offset)
        c
    }

    val activeCalendar = Calendar.getInstance().apply { add(Calendar.DAY_OF_YEAR, selectedDayOffset) }
    val dayFormat = SimpleDateFormat("EEE, MMM d", Locale.getDefault())

    val scheduledOrPublishedShorts = shorts.filter {
        it.status == ShortStatus.SCHEDULED || it.status == ShortStatus.PUBLISHED || it.status == ShortStatus.READY
    }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(DarkBackground)
            .padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Spacer(modifier = Modifier.height(8.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "Content Calendar",
                        color = TextPrimary,
                        fontSize = 20.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "Scheduled YouTube Shorts broadcast windows",
                        color = TextSecondary,
                        fontSize = 12.sp
                    )
                }
                Surface(
                    color = ElectricIndigo.copy(alpha = 0.15f),
                    shape = RoundedCornerShape(10.dp)
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(imageVector = Icons.Default.CalendarToday, contentDescription = null, tint = ElectricIndigo, modifier = Modifier.size(14.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(text = "7-Day View", color = ElectricIndigo, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }

        // 7-day horizontal picker
        item {
            LazyRow(
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items((0..6).toList()) { offset ->
                    val c = Calendar.getInstance().apply { add(Calendar.DAY_OF_YEAR, offset) }
                    val dayName = SimpleDateFormat("EEE", Locale.getDefault()).format(c.time)
                    val dayNum = SimpleDateFormat("d", Locale.getDefault()).format(c.time)
                    val isSelected = selectedDayOffset == offset

                    Card(
                        modifier = Modifier
                            .width(68.dp)
                            .clip(RoundedCornerShape(14.dp))
                            .border(
                                1.dp,
                                if (isSelected) ShortsRed else DarkBorder,
                                RoundedCornerShape(14.dp)
                            )
                            .clickable { selectedDayOffset = offset },
                        colors = CardDefaults.cardColors(
                            containerColor = if (isSelected) ShortsRed.copy(alpha = 0.15f) else DarkSurface
                        ),
                        shape = RoundedCornerShape(14.dp)
                    ) {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 12.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Text(
                                text = if (offset == 0) "Today" else dayName,
                                color = if (isSelected) ShortsRed else TextSecondary,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.SemiBold
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = dayNum,
                                color = if (isSelected) Color.White else TextPrimary,
                                fontSize = 18.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }
            }
        }

        item {
            Text(
                text = "Broadcast Lineup: ${dayFormat.format(activeCalendar.time)}",
                color = TextPrimary,
                fontSize = 15.sp,
                fontWeight = FontWeight.Bold
            )
        }

        if (scheduledOrPublishedShorts.isEmpty()) {
            item {
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .border(1.dp, DarkBorder, RoundedCornerShape(16.dp)),
                    colors = CardDefaults.cardColors(containerColor = DarkSurface),
                    shape = RoundedCornerShape(16.dp)
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(24.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Icon(imageVector = Icons.Default.Schedule, contentDescription = null, tint = TextMuted, modifier = Modifier.size(36.dp))
                        Spacer(modifier = Modifier.height(10.dp))
                        Text("No Shorts Scheduled for This Date", color = TextPrimary, fontSize = 15.sp, fontWeight = FontWeight.Bold)
                        Spacer(modifier = Modifier.height(4.dp))
                        Text("Approved Shorts will automatically appear here.", color = TextSecondary, fontSize = 12.sp)
                    }
                }
            }
        } else {
            items(scheduledOrPublishedShorts) { shortItem ->
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .border(1.dp, DarkBorder, RoundedCornerShape(16.dp))
                        .clickable { onSelectShort(shortItem) }
                        .testTag("calendar_short_${shortItem.id}"),
                    colors = CardDefaults.cardColors(containerColor = DarkSurface),
                    shape = RoundedCornerShape(16.dp)
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            StatusBadge(status = shortItem.status)
                            Text(
                                text = formatEpoch(shortItem.scheduledEpochMillis.takeIf { it > 0 } ?: shortItem.createdAtEpochMillis),
                                color = TextSecondary,
                                fontSize = 12.sp
                            )
                        }

                        Spacer(modifier = Modifier.height(8.dp))

                        Text(
                            text = shortItem.title,
                            color = TextPrimary,
                            fontSize = 14.sp,
                            fontWeight = FontWeight.SemiBold
                        )

                        Spacer(modifier = Modifier.height(4.dp))

                        Text(
                            text = shortItem.hook,
                            color = TextSecondary,
                            fontSize = 12.sp,
                            maxLines = 2
                        )

                        Spacer(modifier = Modifier.height(10.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.End
                        ) {
                            OutlinedButton(
                                onClick = { reschedulingShort = shortItem },
                                shape = RoundedCornerShape(8.dp),
                                border = androidx.compose.foundation.BorderStroke(1.dp, DarkBorder)
                            ) {
                                Icon(imageVector = Icons.Default.EditCalendar, contentDescription = null, tint = TextSecondary, modifier = Modifier.size(14.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("Change Time", color = TextPrimary, fontSize = 11.sp)
                            }
                        }
                    }
                }
            }
        }

        item {
            Spacer(modifier = Modifier.height(40.dp))
        }
    }

    // Rescheduling Dialog
    if (reschedulingShort != null) {
        val short = reschedulingShort!!
        var chosenHourOffset by remember { mutableIntStateOf(3) }

        AlertDialog(
            onDismissRequest = { reschedulingShort = null },
            containerColor = DarkSurface,
            shape = RoundedCornerShape(20.dp),
            title = {
                Text("Reschedule Publishing Slot", color = TextPrimary, fontSize = 16.sp, fontWeight = FontWeight.Bold)
            },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text("Select new target broadcast time:", color = TextSecondary, fontSize = 13.sp)
                    listOf(
                        "In 1 Hour" to 1,
                        "In 3 Hours (Peak Evening)" to 3,
                        "Tomorrow Morning (9:00 AM)" to 18,
                        "Tomorrow Afternoon (3:00 PM)" to 24
                    ).forEach { (label, hours) ->
                        Card(
                            modifier = Modifier
                                .fillMaxWidth()
                                .border(1.dp, if (chosenHourOffset == hours) ShortsRed else DarkBorder, RoundedCornerShape(10.dp))
                                .clickable { chosenHourOffset = hours },
                            colors = CardDefaults.cardColors(
                                containerColor = if (chosenHourOffset == hours) ShortsRed.copy(alpha = 0.15f) else DarkSurfaceVariant
                            )
                        ) {
                            Text(
                                text = label,
                                color = if (chosenHourOffset == hours) Color.White else TextPrimary,
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Medium,
                                modifier = Modifier.padding(12.dp)
                            )
                        }
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        val newTime = System.currentTimeMillis() + (chosenHourOffset * 3600 * 1000L)
                        onReschedule(short.id, newTime)
                        reschedulingShort = null
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = ShortsRed)
                ) {
                    Text("Confirm Reschedule", fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = { reschedulingShort = null }) {
                    Text("Cancel", color = TextSecondary)
                }
            }
        )
    }
}
