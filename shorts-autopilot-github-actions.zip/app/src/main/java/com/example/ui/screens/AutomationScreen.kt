package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AttachMoney
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.Palette
import androidx.compose.material.icons.filled.RecordVoiceOver
import androidx.compose.material.icons.filled.RocketLaunch
import androidx.compose.material.icons.filled.Save
import androidx.compose.material.icons.filled.Schedule
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableDoubleStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.ChannelSettings
import com.example.ui.theme.AccentAmber
import com.example.ui.theme.AccentCyan
import com.example.ui.theme.AccentGreen
import com.example.ui.theme.DarkBackground
import com.example.ui.theme.DarkBorder
import com.example.ui.theme.DarkSurface
import com.example.ui.theme.DarkSurfaceVariant
import com.example.ui.theme.ElectricIndigo
import com.example.ui.theme.ShortsRed
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary

@Composable
fun AutomationScreen(
    currentSettings: ChannelSettings?,
    onSaveSettings: (ChannelSettings) -> Unit,
    modifier: Modifier = Modifier
) {
    val initial = currentSettings ?: ChannelSettings()

    var niche by remember { mutableStateOf(initial.niche) }
    var targetAudience by remember { mutableStateOf(initial.targetAudience) }
    var language by remember { mutableStateOf(initial.language) }
    var countryRegion by remember { mutableStateOf(initial.countryRegion) }
    var durationSeconds by remember { mutableIntStateOf(initial.defaultDurationSeconds) }
    var shortsPerDay by remember { mutableIntStateOf(initial.shortsPerDay) }
    var uploadHour by remember { mutableIntStateOf(initial.uploadHour) }
    var uploadMinute by remember { mutableIntStateOf(initial.uploadMinute) }
    var timeZone by remember { mutableStateOf(initial.timeZone) }
    var voiceStyle by remember { mutableStateOf(initial.voiceStyle) }
    var voiceGender by remember { mutableStateOf(initial.voiceGender) }
    var videoStyle by remember { mutableStateOf(initial.videoStyle) }
    var captionStyle by remember { mutableStateOf(initial.captionStyle) }
    var contentTone by remember { mutableStateOf(initial.contentTone) }
    var isAutoModeEnabled by remember { mutableStateOf(initial.isAutoModeEnabled) }
    var dailyLimit by remember { mutableIntStateOf(initial.dailyLimit) }

    var notifyGen by remember { mutableStateOf(initial.notifyOnGenerated) }
    var notifySched by remember { mutableStateOf(initial.notifyOnScheduled) }
    var notifyPub by remember { mutableStateOf(initial.notifyOnPublished) }
    var notifyFail by remember { mutableStateOf(initial.notifyOnFailure) }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(DarkBackground)
            .padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Spacer(modifier = Modifier.height(8.dp))
            // Section Header
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "Automation & Setup",
                        color = TextPrimary,
                        fontSize = 20.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "Fine-tune AI generation preferences and upload rhythm",
                        color = TextSecondary,
                        fontSize = 12.sp
                    )
                }
                Button(
                    onClick = {
                        val updated = initial.copy(
                            niche = niche,
                            targetAudience = targetAudience,
                            language = language,
                            countryRegion = countryRegion,
                            defaultDurationSeconds = durationSeconds,
                            shortsPerDay = shortsPerDay,
                            uploadHour = uploadHour,
                            uploadMinute = uploadMinute,
                            timeZone = timeZone,
                            voiceStyle = voiceStyle,
                            voiceGender = voiceGender,
                            videoStyle = videoStyle,
                            captionStyle = captionStyle,
                            contentTone = contentTone,
                            isAutoModeEnabled = isAutoModeEnabled,
                            dailyLimit = dailyLimit,
                            notifyOnGenerated = notifyGen,
                            notifyOnScheduled = notifySched,
                            notifyOnPublished = notifyPub,
                            notifyOnFailure = notifyFail
                        )
                        onSaveSettings(updated)
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = ShortsRed),
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier.testTag("save_settings_button")
                ) {
                    Icon(imageVector = Icons.Default.Save, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("Save", fontWeight = FontWeight.Bold)
                }
            }
        }

        // Section 1: Channel Niche & Audience
        item {
            SettingsCard(
                title = "1. Channel Niche & Target Audience",
                icon = Icons.Default.Tune,
                accentColor = ShortsRed
            ) {
                Text(text = "Primary Niche", color = TextSecondary, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                Spacer(modifier = Modifier.height(6.dp))
                val niches = listOf("Facts", "Technology", "History", "Motivation", "Science", "Business", "AI", "Education", "Entertainment")
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    niches.take(5).forEach { n ->
                        FilterChip(
                            selected = niche == n,
                            onClick = { niche = n },
                            label = { Text(n, fontSize = 11.sp) },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = ShortsRed,
                                selectedLabelColor = Color.White
                            )
                        )
                    }
                }
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    niches.drop(5).forEach { n ->
                        FilterChip(
                            selected = niche == n,
                            onClick = { niche = n },
                            label = { Text(n, fontSize = 11.sp) },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = ShortsRed,
                                selectedLabelColor = Color.White
                            )
                        )
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                OutlinedTextField(
                    value = targetAudience,
                    onValueChange = { targetAudience = it },
                    label = { Text("Target Audience Demographic") },
                    modifier = Modifier.fillMaxWidth(),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = ShortsRed,
                        unfocusedBorderColor = DarkBorder,
                        focusedTextColor = TextPrimary,
                        unfocusedTextColor = TextPrimary
                    )
                )

                Spacer(modifier = Modifier.height(10.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    OutlinedTextField(
                        value = language,
                        onValueChange = { language = it },
                        label = { Text("Language") },
                        modifier = Modifier.weight(1f),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = ShortsRed,
                            unfocusedBorderColor = DarkBorder,
                            focusedTextColor = TextPrimary,
                            unfocusedTextColor = TextPrimary
                        )
                    )
                    OutlinedTextField(
                        value = countryRegion,
                        onValueChange = { countryRegion = it },
                        label = { Text("Country/Region") },
                        modifier = Modifier.weight(1f),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = ShortsRed,
                            unfocusedBorderColor = DarkBorder,
                            focusedTextColor = TextPrimary,
                            unfocusedTextColor = TextPrimary
                        )
                    )
                }
            }
        }

        // Section 2: Duration & Scheduling Cadence
        item {
            SettingsCard(
                title = "2. Scheduling & Output Cadence",
                icon = Icons.Default.Schedule,
                accentColor = ElectricIndigo
            ) {
                Text(text = "Shorts Duration (Seconds)", color = TextSecondary, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                Spacer(modifier = Modifier.height(6.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    listOf(15, 30, 45, 60).forEach { dur ->
                        FilterChip(
                            selected = durationSeconds == dur,
                            onClick = { durationSeconds = dur },
                            label = { Text("${dur}s", fontSize = 12.sp, fontWeight = FontWeight.Bold) },
                            modifier = Modifier.weight(1f),
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = ElectricIndigo,
                                selectedLabelColor = Color.White
                            )
                        )
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(text = "Shorts Per Day: $shortsPerDay", color = TextPrimary, fontSize = 14.sp, fontWeight = FontWeight.Bold)
                        Text(text = "Automatic batch generation quota", color = TextSecondary, fontSize = 11.sp)
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        (1..4).forEach { count ->
                            FilterChip(
                                selected = shortsPerDay == count,
                                onClick = { shortsPerDay = count },
                                label = { Text("$count") },
                                colors = FilterChipDefaults.filterChipColors(
                                    selectedContainerColor = ElectricIndigo,
                                    selectedLabelColor = Color.White
                                )
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    OutlinedTextField(
                        value = "$uploadHour:${if (uploadMinute < 10) "0" else ""}$uploadMinute",
                        onValueChange = {},
                        readOnly = true,
                        label = { Text("Daily Upload Time") },
                        modifier = Modifier.weight(1f),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = ElectricIndigo,
                            unfocusedBorderColor = DarkBorder,
                            focusedTextColor = TextPrimary,
                            unfocusedTextColor = TextPrimary
                        )
                    )

                    OutlinedTextField(
                        value = timeZone,
                        onValueChange = { timeZone = it },
                        label = { Text("Time Zone") },
                        modifier = Modifier.weight(1f),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = ElectricIndigo,
                            unfocusedBorderColor = DarkBorder,
                            focusedTextColor = TextPrimary,
                            unfocusedTextColor = TextPrimary
                        )
                    )
                }
            }
        }

        // Section 3: Voice, Video & Caption Aesthetics
        item {
            SettingsCard(
                title = "3. Voice & Visual Creative Direction",
                icon = Icons.Default.Palette,
                accentColor = AccentAmber
            ) {
                Text(text = "Voice Narration Style", color = TextSecondary, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                Spacer(modifier = Modifier.height(6.dp))
                val voiceStyles = listOf("Energetic & Fast-Paced", "Confident Male", "Friendly Female", "Cinematic Narrator")
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    voiceStyles.take(2).forEach { vs ->
                        FilterChip(
                            selected = voiceStyle == vs,
                            onClick = { voiceStyle = vs },
                            label = { Text(vs, fontSize = 11.sp) },
                            modifier = Modifier.weight(1f),
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = AccentAmber,
                                selectedLabelColor = Color.Black
                            )
                        )
                    }
                }
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    voiceStyles.drop(2).forEach { vs ->
                        FilterChip(
                            selected = voiceStyle == vs,
                            onClick = { voiceStyle = vs },
                            label = { Text(vs, fontSize = 11.sp) },
                            modifier = Modifier.weight(1f),
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = AccentAmber,
                                selectedLabelColor = Color.Black
                            )
                        )
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                Text(text = "Visual Animation Style", color = TextSecondary, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                Spacer(modifier = Modifier.height(6.dp))
                val videoStyles = listOf("Cyberpunk / Modern Neon", "Photorealistic Documentary", "Space/Cosmic", "Minimalist Motion")
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    videoStyles.take(2).forEach { vStyle ->
                        FilterChip(
                            selected = videoStyle == vStyle,
                            onClick = { videoStyle = vStyle },
                            label = { Text(vStyle, fontSize = 10.sp) },
                            modifier = Modifier.weight(1f),
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = AccentAmber,
                                selectedLabelColor = Color.Black
                            )
                        )
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                Text(text = "Caption Typography Preset", color = TextSecondary, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                Spacer(modifier = Modifier.height(6.dp))
                listOf("Bold Yellow Pop", "Clean Minimalist", "Karaoke Word-by-Word").forEach { cap ->
                    FilterChip(
                        selected = captionStyle == cap,
                        onClick = { captionStyle = cap },
                        label = { Text(cap, fontSize = 11.sp) },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = AccentAmber,
                            selectedLabelColor = Color.Black
                        ),
                        modifier = Modifier.padding(end = 6.dp)
                    )
                }
            }
        }

        // Section 4: Cost Control & Resource Usage
        item {
            SettingsCard(
                title = "4. Cost Control & Resource Usage",
                icon = Icons.Default.AttachMoney,
                accentColor = AccentGreen
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    UsageMetric(label = "AI Cost (This Month)", value = "$${initial.estimatedAiCostThisMonth}")
                    UsageMetric(label = "Render Units Used", value = "${initial.renderingMinutesUsed}m")
                    UsageMetric(label = "Daily Limit", value = "$dailyLimit Shorts")
                }

                Spacer(modifier = Modifier.height(12.dp))

                Text(
                    text = "Configurable Daily Limit prevents API quota spikes. When limit is reached, AutoPilot holds further generations until the next midnight reset.",
                    color = TextSecondary,
                    fontSize = 11.sp,
                    lineHeight = 15.sp
                )
            }
        }

        // Section 5: Push Notification Alerts
        item {
            SettingsCard(
                title = "5. Notification Settings",
                icon = Icons.Default.Notifications,
                accentColor = AccentCyan
            ) {
                NotificationToggle(
                    title = "Short Generated",
                    subtitle = "Notify when AI script & storyboard is ready for preview",
                    checked = notifyGen,
                    onChecked = { notifyGen = it }
                )
                NotificationToggle(
                    title = "Short Scheduled",
                    subtitle = "Notify when a Short is added to YouTube calendar",
                    checked = notifySched,
                    onChecked = { notifySched = it }
                )
                NotificationToggle(
                    title = "Short Published",
                    subtitle = "Notify upon successful YouTube API broadcast",
                    checked = notifyPub,
                    onChecked = { notifyPub = it }
                )
                NotificationToggle(
                    title = "Generation or Upload Failure",
                    subtitle = "Instant alert if render or YouTube API encounters an error",
                    checked = notifyFail,
                    onChecked = { notifyFail = it }
                )
            }
        }

        item {
            Spacer(modifier = Modifier.height(40.dp))
        }
    }
}

@Composable
private fun SettingsCard(
    title: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    accentColor: Color,
    content: @Composable () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .border(1.dp, DarkBorder, RoundedCornerShape(18.dp)),
        colors = CardDefaults.cardColors(containerColor = DarkSurface),
        shape = RoundedCornerShape(18.dp)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    modifier = Modifier
                        .size(32.dp)
                        .clip(CircleShape)
                        .background(accentColor.copy(alpha = 0.15f)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = icon,
                        contentDescription = null,
                        tint = accentColor,
                        modifier = Modifier.size(16.dp)
                    )
                }
                Spacer(modifier = Modifier.width(10.dp))
                Text(
                    text = title,
                    color = TextPrimary,
                    fontSize = 15.sp,
                    fontWeight = FontWeight.Bold
                )
            }

            Spacer(modifier = Modifier.height(14.dp))

            content()
        }
    }
}

@Composable
private fun UsageMetric(label: String, value: String) {
    Column {
        Text(text = value, color = TextPrimary, fontSize = 18.sp, fontWeight = FontWeight.Bold)
        Spacer(modifier = Modifier.height(2.dp))
        Text(text = label, color = TextSecondary, fontSize = 11.sp)
    }
}

@Composable
private fun NotificationToggle(
    title: String,
    subtitle: String,
    checked: Boolean,
    onChecked: (Boolean) -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 6.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(modifier = Modifier.weight(1f)) {
            Text(text = title, color = TextPrimary, fontSize = 13.sp, fontWeight = FontWeight.Medium)
            Text(text = subtitle, color = TextSecondary, fontSize = 11.sp)
        }
        Switch(
            checked = checked,
            onCheckedChange = onChecked,
            colors = SwitchDefaults.colors(
                checkedThumbColor = Color.White,
                checkedTrackColor = ShortsRed
            )
        )
    }
}
