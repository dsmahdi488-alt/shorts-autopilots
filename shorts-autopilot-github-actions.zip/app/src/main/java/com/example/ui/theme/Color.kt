package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val ShortsRed = Color(0xFFFF0033)
val ShortsRedDark = Color(0xFFCC0029)
val ShortsRedLight = Color(0xFFFF4D6D)

val DarkBackground = Color(0xFF0B0F19)
val DarkSurface = Color(0xFF131B2E)
val DarkSurfaceVariant = Color(0xFF1E293B)
val DarkBorder = Color(0xFF334155)

val ElectricIndigo = Color(0xFF6366F1)
val AccentCyan = Color(0xFF06B6D4)
val AccentAmber = Color(0xFFFBBF24)
val AccentGreen = Color(0xFF10B981)

val TextPrimary = Color(0xFFF8FAFC)
val TextSecondary = Color(0xFF94A3B8)
val TextMuted = Color(0xFF64748B)

val CardGlow = Color(0x33FF0033)
