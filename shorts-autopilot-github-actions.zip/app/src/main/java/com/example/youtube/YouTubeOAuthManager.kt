package com.example.youtube

import android.content.Context
import android.content.Intent
import android.net.Uri
import androidx.activity.ComponentActivity
import net.openid.appauth.AuthState
import net.openid.appauth.AuthorizationException
import net.openid.appauth.AuthorizationRequest
import net.openid.appauth.AuthorizationResponse
import net.openid.appauth.AuthorizationService
import net.openid.appauth.AuthorizationServiceConfiguration
import net.openid.appauth.ResponseTypeValues

/** Real Google OAuth 2.0 client for an installed Android app. */
class YouTubeOAuthManager(private val activity: ComponentActivity) {
    companion object {
        const val REQUEST_CODE = 19042
        const val SCOPE_UPLOAD = "https://www.googleapis.com/auth/youtube.upload"
        const val SCOPE_READONLY = "https://www.googleapis.com/auth/youtube.readonly"
        private const val PREFS = "youtube_oauth"
        private const val AUTH_STATE = "auth_state"
        private const val REDIRECT_URI = "com.example:/oauth2redirect"
        private const val AUTH_ENDPOINT = "https://accounts.google.com/o/oauth2/v2/auth"
        private const val TOKEN_ENDPOINT = "https://oauth2.googleapis.com/token"
    }

    val authorizationService = AuthorizationService(activity)
    private val config = AuthorizationServiceConfiguration(Uri.parse(AUTH_ENDPOINT), Uri.parse(TOKEN_ENDPOINT))

    fun beginAuthorization() {
        val clientId = activity.getString(com.example.R.string.google_android_client_id).trim()
        require(clientId.isNotBlank() && !clientId.startsWith("YOUR_")) {
            "Set GOOGLE_ANDROID_CLIENT_ID before connecting YouTube."
        }
        val request = AuthorizationRequest.Builder(
            config, clientId, ResponseTypeValues.CODE, Uri.parse(REDIRECT_URI)
        ).setScope("openid email profile $SCOPE_UPLOAD $SCOPE_READONLY")
            .setAdditionalParameters(mapOf("access_type" to "offline", "prompt" to "consent"))
            .build()
        activity.startActivityForResult(authorizationService.getAuthorizationRequestIntent(request), REQUEST_CODE)
    }

    fun handleActivityResult(data: Intent?, onComplete: (Result<AuthState>) -> Unit) {
        if (data == null) {
            onComplete(Result.failure(IllegalStateException("Google OAuth returned no data")))
            return
        }
        val response = AuthorizationResponse.fromIntent(data)
        val exception = AuthorizationException.fromIntent(data)
        if (response == null) {
            onComplete(Result.failure(exception ?: IllegalStateException("Google OAuth failed")))
            return
        }
        val state = AuthState(response, exception)
        authorizationService.performTokenRequest(response.createTokenExchangeRequest()) { tokenResponse, tokenException ->
            if (tokenResponse != null) {
                state.update(tokenResponse, tokenException)
                save(state)
                onComplete(Result.success(state))
            } else {
                onComplete(Result.failure(tokenException ?: IllegalStateException("Google token exchange failed")))
            }
        }
    }

    fun getSavedAuthState(): AuthState? = activity.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        .getString(AUTH_STATE, null)?.let { runCatching { AuthState.jsonDeserialize(it) }.getOrNull() }

    fun save(state: AuthState) {
        activity.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
            .putString(AUTH_STATE, state.jsonSerializeString()).apply()
    }

    fun clear() = activity.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().remove(AUTH_STATE).apply()
    fun close() = authorizationService.dispose()
}
