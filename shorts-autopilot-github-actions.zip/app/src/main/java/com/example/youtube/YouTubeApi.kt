package com.example.youtube

import android.net.Uri
import kotlinx.coroutines.suspendCancellableCoroutine
import net.openid.appauth.AuthState
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.asRequestBody
import org.json.JSONObject
import java.io.File
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException

class YouTubeApi(private val authState: AuthState, private val authorizationService: net.openid.appauth.AuthorizationService) {
    private val client = OkHttpClient()

    private suspend fun accessToken(): String = suspendCancellableCoroutine { cont ->
        authState.performActionWithFreshTokens(authorizationService) { token, _, ex ->
            if (ex != null || token == null) cont.resumeWithException(ex ?: IllegalStateException("No access token"))
            else cont.resume(token)
        }
    }

    suspend fun channel(): JSONObject {
        val token = accessToken()
        val request = Request.Builder()
            .url("https://www.googleapis.com/youtube/v3/channels?part=snippet,statistics&mine=true")
            .header("Authorization", "Bearer $token").get().build()
        client.newCall(request).execute().use { response ->
            val body = response.body?.string().orEmpty()
            if (!response.isSuccessful) throw IllegalStateException("YouTube channel lookup failed: ${response.code} $body")
            return JSONObject(body)
        }
    }

    suspend fun uploadShort(file: File, title: String, description: String, tags: List<String>, privacy: String = "public"): String {
        require(file.exists()) { "Rendered MP4 not found: ${file.absolutePath}" }
        val token = accessToken()
        val metadata = JSONObject().apply {
            put("snippet", JSONObject().apply {
                put("title", title.take(100))
                put("description", description.take(5000))
                put("categoryId", "22")
                put("tags", tags.map { it.removePrefix("#") })
            })
            put("status", JSONObject().apply {
                put("privacyStatus", privacy)
                put("selfDeclaredMadeForKids", false)
            })
        }
        val init = Request.Builder()
            .url("https://www.googleapis.com/upload/youtube/v3/videos?uploadType=resumable&part=snippet,status")
            .header("Authorization", "Bearer $token")
            .header("X-Upload-Content-Type", "video/mp4")
            .header("X-Upload-Content-Length", file.length().toString())
            .post(okhttp3.RequestBody.create("application/json".toMediaType(), metadata.toString()))
            .build()
        val uploadUrl = client.newCall(init).execute().use { response ->
            if (!response.isSuccessful) throw IllegalStateException("YouTube upload init failed: ${response.code} ${response.body?.string()}")
            response.header("Location") ?: throw IllegalStateException("YouTube did not return an upload URL")
        }
        val upload = Request.Builder().url(Uri.parse(uploadUrl).toString())
            .header("Authorization", "Bearer $token")
            .header("Content-Type", "video/mp4")
            .put(file.asRequestBody("video/mp4".toMediaType())).build()
        client.newCall(upload).execute().use { response ->
            val body = response.body?.string().orEmpty()
            if (!response.isSuccessful) throw IllegalStateException("YouTube upload failed: ${response.code} $body")
            return JSONObject(body).getString("id")
        }
    }

}
