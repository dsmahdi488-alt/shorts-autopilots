# Build APK from your phone with GitHub Actions

1. Create a new GitHub repository.
2. Upload the contents of this project (not an extra parent folder).
3. Make sure `gradlew` and `gradle/wrapper/` are included.
4. Open **Actions** → **Build Android APK** → **Run workflow**.
5. When it finishes, open the workflow run → **Artifacts** → download `shorts-autopilot-debug-apk`.
6. Extract the downloaded artifact and install the APK on your Android phone.

If the build fails, open the failed workflow, copy the error text, and use it to fix the project.

Do not upload API keys, OAuth client secrets, passwords, or tokens to the repository.
